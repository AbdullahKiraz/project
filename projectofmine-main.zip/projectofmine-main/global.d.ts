// global.d.ts
export {};

declare global {
  interface Window {
    ExperimentSDK?: {
      init: () => Promise<void>;
      //sonra diğer field'ları da eklenebilr
    };
  }
}
