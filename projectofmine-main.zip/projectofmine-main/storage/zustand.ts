import { create } from "zustand";

export const useCartStore = create((set) => ({
  cartItem: 0,
  setCartItem: (count: number) => set({ cartItem: count }),
  increasePopulation: () => set((state) => ({ bears: state.bears + 1 })),
  removeAllBears: () => set({ bears: 0 }),
}));
