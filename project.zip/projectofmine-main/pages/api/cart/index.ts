// pages/api/cart/index.ts
import type { NextApiRequest, NextApiResponse } from "next";
import getDb from "../../../lib/db";
import { v4 } from "uuid";
import {
  getGuestCookie,
  getUserFromCookie,
  setGuestCookie,
} from "../../../lib/auth";
import { users } from "../../../types/types";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const db = await getDb();

  const user: users | null | undefined = await getUserFromCookie(req, res);
  let effectiveId = user?.id;
  //user id yoksa guest_id var mı diye bakıyoruz. Guest id de yoksa onu cookie olarak ekliyorum.
  if (user?.id) {
    effectiveId = user.id;
  } else {
    let guestCookie = getGuestCookie(req, res);

    if (!guestCookie) {
      guestCookie = v4();
      setGuestCookie(req, res, guestCookie);
    }

    effectiveId = guestCookie;
  }

  if (req.method === "GET") {
    const items = await db.all(
      `
      SELECT c.*, p.title, p.price, p.image 
      FROM cart_items c
      JOIN products p ON c.product_id = p.id
      WHERE c.session_id = ?
    `,
      [effectiveId]
    );

    return res.status(200).json(items);
  }

  if (req.method === "POST") {
    const { productId, quantity = 1 } = req.body;

    // Check if item exists
    const existing = await db.get(
      "SELECT * FROM cart_items WHERE session_id = ? AND product_id = ?",
      [effectiveId, productId]
    );

    if (existing) {
      await db.run(
        "UPDATE cart_items SET quantity = quantity + ? WHERE id = ?",
        [quantity, existing.id]
      );
    } else {
      await db.run(
        "INSERT INTO cart_items (session_id, product_id, quantity) VALUES (?, ?, ?)",
        [effectiveId, productId, quantity]
      );
    }

    return res.status(200).json({ success: true });
  }

  if (req.method === "DELETE") {
    const { productId } = req.query;

    await db.run(
      "DELETE FROM cart_items WHERE session_id = ? AND product_id = ?",
      [effectiveId, productId]
    );

    return res.status(200).json({ success: true });
  }

  return res.status(405).json({ error: "Method not allowed" });
}
