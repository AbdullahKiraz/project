import React from "react";

function CouponCode() {
  return (
    <input
      type="text"
      placeholder="Coupon Code"
      className="w-full px-3 py-2 border rounded mb-4"
    />
  );
}

export default CouponCode;
