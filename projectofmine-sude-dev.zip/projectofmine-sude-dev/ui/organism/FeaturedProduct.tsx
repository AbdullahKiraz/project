import Link from "next/link";
import React from "react";
import { products } from "../../types/types";

type FeaturedProductProps = {
  product: products;
};

function FeaturedProduct({ product }: FeaturedProductProps) {
  return (
    <div className="product-card mb-2 w-full bg-white mx-auto rounded-lg shadow hover:shadow-lg transition-shadow">
      <Link href={`/product/${product.id}`}>
        <img
          src={product.image}
          alt={product.title}
          className="h-48 object-cover mx-auto rounded-t-lg product-image"
        />
      </Link>

      <div className="p-4">
        <h3 className="font-semibold mb-2">{product.title}</h3>
        <p className="text-xl font-bold text-blue-600 mb-2">₺{product.price}</p>

        <Link
          href={`/product/${product.id}`}
          className="mt-3 block text-center bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}

export default FeaturedProduct;
