// pages/cart.tsx
import Layout from "../components/Layout";
import { useEffect, useState } from "react";
import { useCartStore } from "../storage/zustand";
import CartLoadingLayout from "../ui/molecule/CartLoadingLayout";
import EmptyCartLayout from "../ui/molecule/EmptyCartLayout";
import CartItems from "../ui/organism/CartItem";
import { CartItem } from "../types/types";
import SubtotalArea from "../ui/organism/SubtotalArea";

export default function Cart() {
  const cartCount = useCartStore((state) => state.cartItem);
  const setCartCount = useCartStore((state) => state.setCartItem);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchCart();
  }, []);

  const fetchCart = async () => {
    const res = await fetch("/api/cart");
    const data = await res.json();
    console.log("cart items : ", data);
    setCartItems(data);
    setLoading(false);
  };

  const removeItem = async (productId: number) => {
    const item = cartItems.find((item: any) => item.product_id === productId);
    if (item) {
      setCartCount(cartCount - item.quantity);
    }

    await fetch(`/api/cart?productId=${productId}`, {
      method: "DELETE",
    });

    fetchCart();
  };

  const updateQuantity = async (productId: number, change: number) => {
    const item = cartItems.find((i: any) => i.product_id === productId);
    setCartCount(cartCount + change);
    if (change < 0 && item && item.quantity <= 1) {
      await removeItem(productId);
      return;
    }

    await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productId,
        quantity: change,
      }),
    });

    fetchCart();
  };

  const calculateTotal = () => {
    return cartItems.reduce(
      (acc: number, item: any) => acc + item.price * item.quantity,
      0
    );
  };

  if (loading) {
    return (
      <Layout>
        <CartLoadingLayout />
      </Layout>
    );
  }

  if (cartItems.length === 0) {
    return (
      <Layout>
        <EmptyCartLayout />
      </Layout>
    );
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-8">Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items - Mobilde full width, desktop'ta 2 kolon */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow p-4 sm:p-6">
            {cartItems.map((item: any) => (
              <div
                key={item.id}
                className="flex flex-col sm:flex-row sm:items-center gap-4 py-4 border-b last:border-0"
              >
                {/* Ürün resmi ve bilgileri */}
                <div className="flex items-center gap-4 flex-1">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm sm:text-base truncate">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 text-sm sm:text-base">
                      ₺{item.price}
                    </p>
                  </div>
                </div>

                {/* Quantity ve işlemler */}
                <div className="flex items-center justify-between sm:justify-end gap-4">
                  {/* Quantity controls */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQuantity(item.product_id, -1)}
                      className="w-8 h-8 rounded border hover:bg-gray-100 flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-medium">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.product_id, 1)}
                      className="w-8 h-8 rounded border hover:bg-gray-100 flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>

                  {/* Toplam fiyat */}
                  <div className="text-base sm:text-lg font-semibold min-w-[80px] text-right">
                    ₺{(item.price * item.quantity).toFixed(2)}
                  </div>

                  {/* Remove butonu */}
                  <button
                    onClick={() => removeItem(item.product_id)}
                    className="text-red-500 hover:text-red-700 text-sm sm:text-base whitespace-nowrap"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Subtotal Area - Mobilde full width, desktop'ta 1 kolon */}
        <div className="lg:col-span-1">
          <SubtotalArea calculateTotal={calculateTotal} />
        </div>
      </div>
    </Layout>
  );
}
