// pages/product/[id].tsx
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import Layout from "../../components/Layout";
import { products } from "../../types/types";
import ProductNotFoundPage from "../../ui/molecule/ProductNotFoundButton";
import ProductLoadinglayout from "../../ui/molecule/ProductLoadinglayout";
import ProductImage from "../../ui/molecule/ProductImage";
import ProductInfo from "../../ui/organism/ProductInfo";
import RelatedProducts from "../../ui/organism/RelatedProducts";

export default function ProductDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [product, setProduct] = useState<products>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedImage, setSelectedImage] = useState<number>(0);

  useEffect(() => {
    if (id) {
      fetchProduct();
    }
  }, [id]);

  const fetchProduct = async () => {
    const res = await fetch(`/api/products/${id}`);
    const data = await res.json();
    setProduct(data);
    setLoading(false);
  };

  const addToCart = async () => {
  // SDK event gönder (isteğe bağlı)
  const cartEvent = new CustomEvent("cart:add", {
    detail: {
      productId: product.id,
      productTitle: product.title,
      timestamp: Date.now(),
    },
  });
  window.dispatchEvent(cartEvent);

  // API isteği
  await fetch("/api/cart", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ productId: product.id, quantity }),
  });

  

  // ✅ TOAST BİLDİRİMİ (Reload yapmaz)
  const toast = document.createElement("div");
  toast.className = `
    fixed top-4 right-4 bg-green-600 text-white
    px-4 py-2 rounded shadow-lg z-50 animate-fade
  `;
  toast.textContent = `${quantity} x ${product.title} added to cart!`;

  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 1500);
};

  if (loading) {
    return (
      <Layout>
        <ProductLoadinglayout />
      </Layout>
    );
  }

  if (!product) {
    return (
      <Layout>
        <ProductNotFoundPage />
      </Layout>
    );
  }

  // Generate multiple images for gallery
  const images = [
    product.image,
    product.image.replace("random=", "random=a"),
    product.image.replace("random=", "random=b"),
    product.image.replace("random=", "random=c"),
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <ProductImage
          images={images}
          selectedImage={selectedImage}
          setSelectedImage={setSelectedImage}
          product={product}
        />
        {/* Product Info */}
        <ProductInfo
          product={product}
          quantity={quantity}
          setQuantity={setQuantity}
          addToCart={addToCart}
        />
      </div>
      {/* Related Products */}
      <RelatedProducts />
    </Layout>
  );
}
