// pages/api/scenarios/trigger.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import getDb from '../../../lib/db';

// Yerel saat + milisaniye üreten küçük helper
function formatLocalTimestampWithMs() {
  const d = new Date(); 

  const year   = d.getFullYear();
  const month  = String(d.getMonth() + 1).padStart(2, '0');
  const day    = String(d.getDate()).padStart(2, '0');
  const hour   = String(d.getHours()).padStart(2, '0');
  const minute = String(d.getMinutes()).padStart(2, '0');
  const second = String(d.getSeconds()).padStart(2, '0');
  const ms     = String(d.getMilliseconds()).padStart(3, '0');

  return `${year}-${month}-${day} ${hour}:${minute}:${second}:${ms}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { sessionId, scenarioId, status } = req.body;
  const db = await getDb();

  const triggeredAt = formatLocalTimestampWithMs();

  await db.run(
    `INSERT INTO scenario_triggers (
       session_id,
       scenario_id,
       status,
       triggered_at
     ) VALUES (?, ?, ?, ?)`,
    [sessionId, scenarioId, status, triggeredAt]
  );

  res.status(200).json({ success: true });
}
