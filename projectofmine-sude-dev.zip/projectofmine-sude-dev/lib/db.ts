// lib/db.ts
import { open } from "sqlite";
import sqlite3 from "sqlite3";
import path from "path";

let db: any = null;

export async function getDb() {
  if (!db) {
    db = await open({
      filename: path.join(process.cwd(), "experiment.db"),
      driver: sqlite3.Database,
    });

    await initDb();
  }
  return db;
}
async function initDb() {
  await db.exec(`
    -- Sessions table
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      experiment_group TEXT DEFAULT 'control',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      user_agent TEXT,
      ip TEXT
    );

    -- Events table
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT,
      event_type TEXT,
      event_data TEXT,
      page_url TEXT,
      timestamp INTEGER,
      relative_t_ms INTEGER,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (session_id) REFERENCES sessions(id)
    );

    -- Experiments table
    CREATE TABLE IF NOT EXISTS experiments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      status TEXT DEFAULT 'draft',
      control_weight INTEGER DEFAULT 50,
      variant_a_weight INTEGER DEFAULT 25,
      variant_b_weight INTEGER DEFAULT 25,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Scenarios table
    CREATE TABLE IF NOT EXISTS scenarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      type TEXT,
      target_page TEXT,
      selector TEXT,
      params TEXT,
      probability REAL DEFAULT 0.1,
      enabled INTEGER DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Products table
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      price REAL,
      image TEXT,
      category TEXT,
      stock INTEGER DEFAULT 100,
      description TEXT
    );

    -- Cart items
    CREATE TABLE IF NOT EXISTS cart_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT,
      product_id INTEGER,
      quantity INTEGER DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (session_id) REFERENCES sessions(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- Scenario triggers log
    CREATE TABLE IF NOT EXISTS scenario_triggers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT,
      scenario_id INTEGER,
      status TEXT,
      triggered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (session_id) REFERENCES sessions(id),
      FOREIGN KEY (scenario_id) REFERENCES scenarios(id)
    );

    -- Users table
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      password TEXT,
      role TEXT DEFAULT 'user',
      name TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 👉 Seed ONLY if empty (Doğru mantık)
  const productCount = await db.get("SELECT COUNT(*) AS c FROM products");
  if (productCount.c === 0) await seedProducts();

  const scenarioCount = await db.get("SELECT COUNT(*) AS c FROM scenarios");
  if (scenarioCount.c === 0) await seedScenarios();

  const userCount = await db.get("SELECT COUNT(*) AS c FROM users");
  if (userCount.c === 0) await seedUsers();
}


async function seedProducts() {
  const products = [
    { title: "Laptop Pro X1", price: 15999.99, category: "electronics", image: "/images/laptop.png" },
    { title: "Wireless Mouse", price: 299.99, category: "electronics", image: "/images/wireless-mouse.jpg" },
    { title: "USB-C Hub", price: 549.99, category: "electronics", image: "/images/hub.jpg" },
    { title: "Mechanical Keyboard", price: 1299.99, category: "electronics", image: "/images/MechanicalKeyboard.jpg" },
    { title: 'Monitor 27"', price: 7999.99, category: "electronics", image: "/images/Monitor.jpg" },
    { title: "Webcam HD", price: 899.99, category: "electronics", image: "/images/WebcamHD.jpg" },
    { title: "Desk Lamp LED", price: 449.99, category: "home", image: "/images/DeskLampLED.jpg" },
    { title: "Office Chair", price: 3999.99, category: "home", image: "/images/OfficeChair.jpg" },
    { title: "Standing Desk", price: 8999.99, category: "home", image: "/images/StandingDesk.jpg" },
    { title: "Coffee Maker", price: 1899.99, category: "home", image: "/images/CoffeeMaker.jpeg" },
    { title: "Bluetooth Speaker", price: 799.99, category: "electronics", image: "/images/BluetoothSpeaker.jpg" },
    { title: "Gaming Headset", price: 1499.99, category: "electronics", image: "/images/GamingHeadset.jpg" },
    { title: "Smart Watch", price: 3499.99, category: "electronics", image: "/images/SmartWatch.jpg" },
    { title: "Portable SSD 1TB", price: 1999.99, category: "electronics", image: "/images/PortableSSD1TB.jpg" },
    { title: "Robot Vacuum", price: 6999.99, category: "home", image: "/images/RobotVacuum.jpg" },
    { title: "Air Purifier", price: 2799.99, category: "home", image: "/images/AirPurifier.jpg" },
    { title: "Bookshelf", price: 1299.99, category: "home", image: "/images/Bookshelf.jpeg" },
    { title: "Smart Lock", price: 2499.99, category: "home", image: "/images/SmartLock.jpg" },
    { title: "Power Bank 20000mAh", price: 899.99, category: "electronics", image: "/images/PowerBank20000mAh.jpg" },
    { title: "Digital Photo Frame", price: 1199.99, category: "home", image: "/images/DigitalPhotoFrame.jpeg" },
  ];

  for (const p of products) {
    await db.run(
      `INSERT INTO products (title, price, category, image, description)
       SELECT ?, ?, ?, ?, ?
       WHERE NOT EXISTS (SELECT 1 FROM products WHERE title = ?)`,
      [
        p.title,
        p.price,
        p.category,
        p.image,
        `High quality ${p.title} with premium features and warranty.`,
        p.title, // WHERE NOT EXISTS için
      ]
    );
  }
}

  

async function seedScenarios() {
  const scenarios = [
    // A) Loading/Visual Scenarios
    {
      name: "Slow Image Load",
      type: "slow_image",
      target_page: "/products",
      selector: ".product-image",
      params: JSON.stringify({ delay: 3000 }),
      probability: 1.0,
    },
    {
      name: "Broken Image",
      type: "broken_image",
      target_page: "/products",
      selector: ".product-image",
      params: JSON.stringify({ probability: 0.5 }),
      probability: 1.0,
    },
    {
      name: "Skeleton Prolong",
      type: "skeleton_prolong",
      target_page: "/products",
      selector: ".product-card",
      params: JSON.stringify({ delay: 4000 }),
      probability: 1.0,
    },

    // B) Interaction/Friction Scenarios
    {
      name: "Button Delay",
      type: "button_delay",
      target_page: "*",
      selector: ".add-to-cart",
      params: JSON.stringify({ delay: 3000 }),
      probability: 1.0,
    },
    {
      name: "First Click Miss",
      type: "first_click_miss",
      target_page: "*",
      selector: "button",
      params: JSON.stringify({}),
      probability: 1.0,
    },
    {
      name: "Feedback Late",
      type: "feedback_late",
      target_page: "*",
      selector: null,
      params: JSON.stringify({ delay: 3000 }),
      probability: 1.0,
    },

    // C) Search/Navigation Scenarios
    {
      name: "Search Irrelevant",
      type: "search_irrelevant",
      target_page: "*",
      selector: null,
      params: JSON.stringify({ duration: 5000 }),
      probability: 1.0,
    },
    {
      name: "Facet Reset Once",
      type: "facet_reset_once",
      target_page: "*",
      selector: null,
      params: JSON.stringify({}),
      probability: 1.0,
    },
    {
      name: "Sort Reset",
      type: "sort_reset",
      target_page: "*",
      selector: null,
      params: JSON.stringify({}),
      probability: 1.0,
    },

    // D) Data Consistency Scenarios
    {
      name: "Price Change Warning",
      type: "price_change",
      target_page: "*",
      selector: null,
      params: JSON.stringify({ change_percent: 5 }),
      probability: 1.0,
    },

    // E) Cart/Coupon Scenarios
    //{
    //  name: "Coupon Min Spend",
    //  type: "coupon_min_spend",
    //  target_page: "/cart",
    //  selector: null,
    //  params: JSON.stringify({ min_amount: 500 }),
    //  probability: 0.6,
    //},
    //{
    // name: "Coupon Expired",
    //  type: "coupon_expired",
    //  target_page: "/cart",
    //  selector: null,
    //  params: JSON.stringify({}),
    //  probability: 0.3,
    //},


    // G) Overlay/Attention Scenarios
    //{
    //  name: "Overlay Blocking",
    //  type: "overlay_blocking",
    //  target_page: "/",
    //  selector: null,
    //  params: JSON.stringify({ duration: 4000 }),
    //  probability: 0.3,
    //},

    // H) Network Scenarios
    {
      name: "Network Jitter",
      type: "network_jitter",
      target_page: "*",
      selector: null,
      params: JSON.stringify({ delay: 3000 }),
      probability: 1.0,
    },
  ];

    for (const s of scenarios) {
    await db.run(
      `INSERT INTO scenarios (name, type, target_page, selector, params, probability, enabled)
       SELECT ?, ?, ?, ?, ?, ?, 1
       WHERE NOT EXISTS (SELECT 1 FROM scenarios WHERE name = ?)`,
      [
        s.name,
        s.type,
        s.target_page,
        s.selector,
        s.params,
        s.probability,
        s.name, // WHERE NOT EXISTS için
      ]
    );
  }
}

async function seedUsers() {
  const users = [
    {
      email: "admin@test.com",
      password: "admin123", // In production, use bcrypt
      role: "admin",
      name: "Admin User",
    },
    {
      email: "user@test.com",
      password: "user123",
      role: "user",
      name: "Test User",
    },
  ];

  for (const u of users) {
    await db.run(
      "INSERT INTO users (email, password, role, name) VALUES (?, ?, ?, ?)",
      [u.email, u.password, u.role, u.name]
    );
  }
}

export default getDb;
