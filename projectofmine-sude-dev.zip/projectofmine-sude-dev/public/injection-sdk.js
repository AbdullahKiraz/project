// public/injection-sdk.js
(function() {
  'use strict';

  window.ExperimentSDK = {
    sessionId: null,
    experimentGroup: null,
    scenarios: [],
    triggeredScenarios: new Map(),
    eventQueue: [],
    pageLoadTime: Date.now(),
    scenariosPerSession: 0,
    lastScenarioTime: 0,

    COOLDOWN_MS: 12000, // 12 seconds
    MAX_SCENARIOS_PER_SESSION: 10,

    init: async function() {
      // Get session info
      const res = await fetch('/api/session/info');
      const data = await res.json();

      this.sessionId = data.sessionId || null;
      this.experimentGroup = data.experimentGroup || 'control';

      if (!this.sessionId) {
        console.warn('[SDK] No sessionId returned, forcing control mode');
        this.experimentGroup = 'control';
      } else {
        console.log('🚀 SDK Initialized:', {
          sessionId: this.sessionId.substring(0, 8),
          group: this.experimentGroup
        });
      }

      // Load & start scenarios
      if (this.experimentGroup !== 'control') {
        await this.loadScenarios();
        this.startScenarioWatcher();
      }

      // Track events
      this.trackPageView();
      this.attachEventListeners();

      // Batch send events
      setInterval(() => this.flushEvents(), 2000);
    },

    loadScenarios: async function() {
      const res = await fetch(
        `/api/scenarios/active?page=${encodeURIComponent(window.location.pathname)}&group=${this.experimentGroup}`
      );
      const allScenarios = await res.json();

      this.scenarios = allScenarios.filter(s => s.enabled === 1);

      console.log("📦 Loaded Active Scenarios:", this.scenarios.map(s => ({
        id: s.id,
        name: s.name,
        type: s.type,
        probability: s.probability
      })));
    },

    startScenarioWatcher: function() {
      setInterval(() => {
        const now = Date.now();
        const timeSinceLoad = now - this.pageLoadTime;

        // Cooldown check
        if (this.lastScenarioTime && (now - this.lastScenarioTime) < this.COOLDOWN_MS) return;

        // Per-session max limit
        if (this.scenariosPerSession >= this.MAX_SCENARIOS_PER_SESSION) return;

        this.scenarios.forEach(scenario => {
          if (this.triggeredScenarios.has(scenario.id)) return;
          if (!scenario.enabled) return;

          let effectiveProbability = scenario.probability;

          // Group-based scaling
          if (this.experimentGroup === 'variant_a') {
            effectiveProbability *= 0.3;
          } else if (this.experimentGroup === 'variant_b') {
            effectiveProbability *= 0.6;
          }

          // Probability check
          if (Math.random() > effectiveProbability) return;

          // Minimum load delay
          if (timeSinceLoad > 3000) {
            this.executeScenario(scenario);
          }
        });
      }, 1000);
    },

    executeScenario: function(scenario) {
      if (this.triggeredScenarios.has(scenario.id)) return;

      const now = Date.now();
      if (this.lastScenarioTime && (now - this.lastScenarioTime) < this.COOLDOWN_MS) return;
      if (this.scenariosPerSession >= this.MAX_SCENARIOS_PER_SESSION) return;

      this.triggeredScenarios.set(scenario.id, now);
      this.scenariosPerSession++;
      this.lastScenarioTime = now;

      const params = JSON.parse(scenario.params || '{}');
      console.log("⚡ Executing Scenario:", scenario.type, params);

      this.logEvent('scenario_start', {
        scenario_id: scenario.id,
        type: scenario.type,
        name: scenario.name
      });

      // 🔥 FINAL SWITCH — SADECE AKTİF 10 TÜR VAR
      switch (scenario.type) {

        /* ---------------------------
           A) LOADING / VISUAL
        ----------------------------*/
        case 'slow_image':
          this.slowImageLoad(scenario.selector, params.delay || 3000);
          break;

        case 'broken_image':
          this.brokenImage(scenario.selector);
          break;

        case 'skeleton_prolong':
          this.skeletonProlong(scenario.selector, params.delay || 2000);
          break;

        /* ---------------------------
           B) INTERACTION / FRICTION
        ----------------------------*/
        case 'button_delay':
          this.buttonDelay(scenario.selector, params.delay || 6000);
          break;

        case 'first_click_miss':
          this.firstClickMiss(scenario.selector);
          break;

        case 'feedback_late':
          this.feedbackLate(params.delay || 6000);
          break;

        /* ---------------------------
           C) FILTER RESET
        ----------------------------*/
        case 'facet_reset_once':
        case 'sort_reset':
          this.resetFilters();
          break;

        /* ---------------------------
           D) PRICE CHANGE
        ----------------------------*/
        case 'price_change':
          this.priceChangeWarning(params.change_percent || 5);
          break;

        /* ---------------------------
           E) NETWORK ISSUES
        ----------------------------*/
        case 'network_jitter':
          this.networkJitter(params.delay || 5500);
          break;

        /* ---------------------------
           ❌ PASİF SENARYOLAR (COMMENT)
        ----------------------------*/

        
        case 'search_irrelevant':
          this.searchIrrelevant(params.duration || 5000);
          break;
      /* 
        case 'coupon_min_spend':
        case 'coupon_expired':
          this.couponError(scenario.type);
          break;

        case 'overlay_blocking':
          this.overlayBlocking(params.duration || 4000);
          break;

        case '3ds_soft_fail':
          this.threeDSSoftFail();
          break;

        case 'payment_retry_timeout':
          this.paymentTimeout();
          break;
        */

        default:
          console.warn("⚠ Unknown scenario (but harmless):", scenario.type);
      }

      // Register scenario trigger
      fetch('/api/scenarios/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: this.sessionId,
          scenarioId: scenario.id,
          status: 'triggered'
        })
      });

      setTimeout(() => {
        this.logEvent('scenario_end', {
          scenario_id: scenario.id,
          type: scenario.type
        });
      }, params.delay || params.duration || 2000);
    },

    /* ---------------------------------------------------
       SCENARIO IMPLEMENTATIONS (Only 10 are active)
    --------------------------------------------------- */

    slowImageLoad: function(selector, delay) {
      const images = document.querySelectorAll(selector || '.product-image, img');
      images.forEach((img, index) => {
        if (index < 3) {
          const originalSrc = img.src;
          img.style.filter = 'blur(8px)';
          img.classList.add('animate-pulse');

          setTimeout(() => {
            img.src = originalSrc + '?t=' + Date.now();
            img.classList.remove('animate-pulse');
            img.style.filter = 'none';
          }, delay);
        }
      });
    },

    brokenImage: function(selector) {
      const images = document.querySelectorAll(selector || '.product-image');
      if (images.length === 0) return;

      const random = images[Math.floor(Math.random() * Math.min(3, images.length))];
      random.src =
        'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23f3f4f6" width="400" height="300"/%3E%3Ctext fill="%23999" x="50%25" y="50%25" text-anchor="middle"%3EImage%20not%20available%3C/text%3E%3C/svg%3E';
    },

    skeletonProlong: function(selector, delay) {
      const elements = document.querySelectorAll(selector || '.product-card');
      elements.forEach(el => {
        el.classList.add('animate-pulse');
        setTimeout(() => el.classList.remove('animate-pulse'), delay);
      });
    },

    buttonDelay: function(selector, delay) {
  const buttons = document.querySelectorAll(
    selector || ".add-to-cart, button[type='submit']"
  );

  buttons.forEach((btn) => {
    const originalText = btn.textContent;

    btn.addEventListener(
      "click",
      (e) => {
        e.stopImmediatePropagation(); // React event’lerini KORUR
        e.preventDefault();           // tıklamayı geciktirir

        btn.disabled = true;
        btn.style.opacity = "0.6";
        btn.textContent = "Processing...";

        setTimeout(() => {
          btn.disabled = false;
          btn.style.opacity = "1";
          btn.textContent = originalText;

          // React onClick tetiklensin
          const clickEvent = new MouseEvent("click", { bubbles: true });
          btn.dispatchEvent(clickEvent);
        }, delay);
      },
      true // capture mode → React'ten önce çalışır ama bozmaz
    );
  });
},


    firstClickMiss: function(selector) {
      const buttons = document.querySelectorAll(selector || 'button');
      buttons.forEach(btn => {
        let first = true;
        const orig = btn.onclick;

        btn.onclick = e => {
          if (first) {
            first = false;
            e.preventDefault();
            btn.style.transform = 'scale(0.98)';
            setTimeout(() => (btn.style.transform = ''), 150);
            return false;
          }
          if (orig) return orig(e);
        };
      });
    },

    feedbackLate: function(delay) {
      const orig = window.alert;
      window.alert = msg => setTimeout(() => orig(msg), delay);
    },

    resetFilters: function() {
      document.querySelectorAll('input[type="checkbox"], input[type="radio"]').forEach(i => {
        i.checked = false;
      });
      document.querySelectorAll('select').forEach(s => (s.selectedIndex = 0));
      this.showToast("Filters reset", "warning", 1500);
    },

    priceChangeWarning: function(change) {
      if (!window.location.pathname.includes("checkout")) return;

      const banner = document.createElement('div');
      banner.className = "bg-yellow-100 border-l-4 border-yellow-500 p-4 mb-4";
      banner.textContent = `⚠️ Price updated: ${change}% change detected`;

      const container = document.querySelector('main');
      if (container) container.prepend(banner);

      setTimeout(() => banner.remove(), 4000);
    },

    networkJitter: function(delay) {
      const orig = window.fetch;
      window.fetch = (...args) =>
        new Promise(resolve =>
          setTimeout(() => resolve(orig(...args)), delay)
        );

      setTimeout(() => (window.fetch = orig), 10000);
    },

    /* ----------------- UTILS ----------------- */

    showToast: function(msg, type = 'info', duration = 2000) {
      const toast = document.createElement('div');
      toast.className =
        "fixed top-4 right-4 px-4 py-2 rounded shadow text-white z-50 " +
        (type === "warning" ? "bg-yellow-500" : "bg-blue-500");

      toast.textContent = msg;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), duration);
    },

    trackPageView: function() {
      this.logEvent("page_view", {
        url: location.href,
        title: document.title
      });
    },

    attachEventListeners: function() {
      document.addEventListener("click", e => {
        if (e.target.tagName === "BUTTON" || e.target.tagName === "A") {
          this.logEvent("click", {
            elem: e.target.tagName,
            text: e.target.textContent?.slice(0, 40)
          });
        }
      });
    },

    logEvent: function(type, data) {
      this.eventQueue.push({
        sessionId: this.sessionId,
        eventType: type,
        eventData: data,
        pageUrl: location.href,
        timestamp: Date.now()
      });
    },

    flushEvents: async function() {
      if (this.eventQueue.length === 0) return;

      const events = [...this.eventQueue];
      this.eventQueue = [];

      try {
        await fetch("/api/events/batch", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(events)
        });
      } catch (e) {
        this.eventQueue.push(...events);
      }
    }
  };

})();
